from book import Book

class Library:
    """
    A class to represent the library and manage book operations.
    
    Attributes:
        available_books (list): List of books currently available for borrowing
        borrowed_books (list): List of books currently borrowed by users
    """
    def __init__(self):
        """Initialize an empty list to store books"""
        self.books = []

    def add_book(self, book: Book):
        """Add a book to the library"""
        self.books.append(book)
        print(f"Book '{book.title}' added to library.")

    def remove_book(self, title: str):
        """Remove a book by title"""
        for book in self.books:
            if book.title.lower() == title.lower():
                self.books.remove(book)
                print(f"Book '{title}' removed.")
                return
        print(f"Book '{title}' not found.")

    def search_book(self, keyword: str):
        """Search books by title or author"""
        found = []
        for book in self.books:
            if keyword.lower() in book.title.lower() or keyword.lower() in book.author.lower():
                found.append(book)
        return found

    def borrow_book(self, title: str):
        """Borrow a book by title"""
        for book in self.books:
            if book.title.lower() == title.lower():
                return book.borrow()  
        print(f"Book '{title}' not found.")
        return False

    def return_book(self, title: str):
        """Return a book by title"""
        for book in self.books:
            if book.title.lower() == title.lower():
                return book.return_book()  
        print(f"Book '{title}' not found.")
        return False

    def list_all_books(self):
        """Display all books in the library"""
        if not self.books:
            print("No books in library.")
            return
        print("\n===== ALL BOOKS =====")
        for idx, book in enumerate(self.books, 1):
            print(f"Book {idx}:\n{book}\n")

    def list_popular_books(self):
        """Display popular books (rating ≥4 and borrowed ≥5 times)"""
        popular = [book for book in self.books if book.is_popular()]
        if not popular:
            print("No popular books.")
            return
        print("\n===== POPULAR BOOKS =====")
        for idx, book in enumerate(popular, 1):
            print(f"Popular Book {idx}:\n{book}\n")

