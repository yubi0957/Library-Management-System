# main.py — Main Program
from book import Book  
from library import Library
def main():
    library = Library()

    library.add_book(Book("Python Crash Course", "Eric Matthes", 4.7, 39.99))
    library.add_book(Book("Deep Learning", "Ian Goodfellow", 4.5, 129.99))

    while True:
        print("\n===== 📚 Library Management System 📚 =====")
        print("1. 📖 Add Book")
        print("2. ❌ Remove Book")
        print("3. 🔍 Search Book")
        print("4. 📤 Borrow Book")
        print("5. 📥 Return Book")
        print("6. 📋 List All Books")
        print("7. ⭐ Show Popular Books")
        print("8. 👋 Exit")

        choice = input("Enter your choice (1-8): ")

        if choice == "1":
            title = input("Enter book title: ")
            author = input("Enter author: ")
            rating = float(input("Enter rating (0-5): "))
            price = float(input("Enter price: $"))
            new_book = Book(title, author, rating, price)
            library.add_book(new_book)

        elif choice == "2":
            title = input("Enter title to remove: ")
            library.remove_book(title)

        elif choice == "3":
            keyword = input("Enter search keyword: ")
            results = library.search_book(keyword)
            if results:
                print("\n===== (?) SEARCH RESULTS (?) =====")
                for book in results:
                    print(book)
            else:
                print("(x) No matching books found.")

        elif choice == "4":
            title = input("Enter title to borrow: ")
            library.borrow_book(title)

        elif choice == "5":
            title = input("Enter title to return: ")
            library.return_book(title)

        elif choice == "6":
            library.list_all_books()

        elif choice == "7":
            library.list_popular_books()

        elif choice == "8":
            print("<=== Exiting system. Goodbye! ===>")
            break

        else:
            print("(x) Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
