'''
Book.py — Book Module

This module defines the Book class used in the library management system.

Attributes:
        title (str): The title of the book
        author (str): The author of the book
        rating (float): The rating of the book (0-5 scale)
        price (float): The price of the book
'''
class Book:
    def __init__(self, title:str, author:str, rating:float, price:float):
        """
        Constructs all the necessary attributes for the book object.
        
        Parameters:
            title (str): The title of the book
            author (str): The author of the book
            rating (float): The rating of the book (0-5 scale)
            price (float): The price of the book
        """
        self.title = title
        self.author = author
        self.rating = rating
        self.price = price
        self.is_borrowed = False
        self.borrow_count = 0
    
    def __str__(self):
        """Returns a formatted string representation of the book"""
        content_lines = [
            f"Title: {self.title}",
            f"Author: {self.author}",
            f"Rating: {self.rating}",
            f"Price: ${self.price:.2f}",
            f"Times Borrowed: {self.borrow_count}"
        ]
        
        # Calculate the maximum length of content lines
        max_length = 0
        for line in content_lines:
            if len(line) > max_length:
                max_length = len(line)
        header_length = max_length + 2  # Header rows are 2 longer
        
        # Create header rows
        header = " BOOK INFORMATION ".center(header_length, '=')
        
        # Output format
        content_str = ""  
        for line in content_lines:
            content_str += line + "\n"  

        return f"{header}\n{content_str}"

    def borrow(self):
        """borrow this book"""
        if not self.is_borrowed:
            self.is_borrowed = True
            self.borrow_count += 1
            print(f"{self.title} successfully borrowed!")
            return True
        else:
            print(f"Sorry, {self.title} has been borrowed.")
            return False
    
    def return_book(self):
        """Return this book"""
        if self.is_borrowed:
            self.is_borrowed = False
            print(f"{self.title} successfully return!")
            return True
        else:
            print(f"{self.title} has not been borrowed.")
            return False
    
    def is_popular(self):
        """Determine if the book is popular(raing ≥ 4 and borrow_count ≥ 5)"""
        return self.rating >= 4 and self.borrow_count >= 5 

if __name__ == '__main__':
    # ===== Test Code =====
    print("\n===== Test code ======\n")
    
    # Test Class Book
    book1 = Book("Python Crash Course", "Eric Matthes", 4.7, 39.99)
    print(book1)
    book2 = Book("Deep Learning", "Ian Goodfellow", 4.5, 129.99)
    print(book2)
    
